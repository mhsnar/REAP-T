function varargout=inv(varargin)
%INV

disp('INV is not defined on general SDPVAR objects')
disp('Learn about <a href="yalmip.github.io/faq/inverse/">alternatives</a>')
