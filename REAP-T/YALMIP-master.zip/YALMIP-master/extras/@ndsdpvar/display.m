function F = display(X)
% DISPLAY Overloaded

d = X.dim;
disp(['Multi-dimensional SDPVAR object ' sizestring(d)])

