function assign(x,y)
% assign (overloaded)

assign(sdpvar(x),y(:));